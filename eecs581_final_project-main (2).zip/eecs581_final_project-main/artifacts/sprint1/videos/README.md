Storage space for all sprint 1 related demo videos.
